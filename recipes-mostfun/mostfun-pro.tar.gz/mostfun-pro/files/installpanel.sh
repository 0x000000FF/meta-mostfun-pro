#!/bin/bash
echo "starting decode apps"
cd /mostfun
/mostfun/decode.mostfun /mostfun/mostfun.des3
echo "decode apps done"
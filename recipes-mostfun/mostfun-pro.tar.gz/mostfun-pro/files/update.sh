#!/bin/bash
opkg upate > /tmp/opkgupdate.txt
opkg upgrade > /tmp/opkgupgrade.txt